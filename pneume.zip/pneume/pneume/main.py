import pickle
from model import Model
from flask import Flask

app = Flask(__name__)

@app.get("/predict")
def main():
    with open('model.pickle', 'rb') as f:
        m = pickle.load(f)

    img = []
    return {"isInfected": m.is_pneumonia_found(img)}

app.run()

