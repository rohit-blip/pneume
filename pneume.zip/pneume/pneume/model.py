from random import randint
import pickle
from time import sleep

class Model:
    def is_pneumonia_found(self, _):
        sleep(2)
        return [True, False][randint(0, 1)]

